# Zephyr Replay Player — prototipo Android 0.1

Proyecto Android nativo inicial para generar un APK de prueba. Permite seleccionar un archivo `.yrp3d`, leer sus primeros bytes y mostrar un diagnóstico básico.

## Estado real
- Importación de archivos Android: implementada.
- Lectura inicial del archivo: implementada.
- Decodificación completa del formato de replay: pendiente.
- Reproducción audiovisual del duelo: pendiente.
- Integración del motor compatible con MDPro4/EDOPro: pendiente.
- Cartas personalizadas Zephyr Mirage / Obsidian Terracore: pendiente.

**Importante:** esta versión es una app Android instalable cuando se compila, pero todavía no reproduce los duelos. No presenta jugadas falsas como si fueran reales.

## Cómo obtener el APK sin instalar Android Studio
1. Subí este proyecto a un repositorio de GitHub.
2. Abrí la pestaña **Actions** del repositorio.
3. Elegí **Build Android APK** y tocá **Run workflow** (o esperá a que termine el primer build tras subirlo a `main`).
4. Abrí la ejecución completada y descargá el artefacto `Zephyr-Replay-Player-debug-apk`.
5. Descomprimí el artefacto y abrí `app-debug.apk` en Android para instalarlo. Puede que Android pida permitir instalaciones desde esa fuente.

## Compilar con Android Studio
Abrí esta carpeta como proyecto Android y ejecutá la tarea `assembleDebug`. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.
