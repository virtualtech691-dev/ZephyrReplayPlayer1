package com.zephyr.replayplayer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var details: TextView

    companion object {
        private const val PICK_REPLAY = 4101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "ZEPHYR REPLAY PLAYER"
            textSize = 22f
            setTextColor(0xFFE8F0F2.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Importá una repetición .yrp3d para analizar su encabezado."
            textSize = 16f
            setTextColor(0xFFB9CBD1.toInt())
            setPadding(0, pad, 0, pad)
        }
        val pick = Button(this).apply {
            text = "ABRIR REPETICIÓN"
            setOnClickListener { openReplayPicker() }
        }
        details = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFE8F0F2.toInt())
            setPadding(0, pad, 0, pad)
            text = "Proyecto inicial\\n\\nLa reproducción del duelo todavía no está implementada."
        }
        val note = TextView(this).apply {
            text = "Versión 0.1 · Importación y diagnóstico inicial"
            textSize = 12f
            setTextColor(0xFF82969D.toInt())
        }

        layout.addView(title, LinearLayout.LayoutParams(-1, -2))
        layout.addView(status, LinearLayout.LayoutParams(-1, -2))
        layout.addView(pick, LinearLayout.LayoutParams(-1, -2))
        layout.addView(details, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(note, LinearLayout.LayoutParams(-1, -2))
        setContentView(layout)
    }

    private fun openReplayPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream",
                "application/x-yrp3d"
            ))
        }
        startActivityForResult(intent, PICK_REPLAY)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_REPLAY || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        contentResolver.takePersistableUriPermission(
            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        inspectReplay(uri)
    }

    private fun inspectReplay(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(64)
                val count = input.read(buffer)
                if (count <= 0) ByteArray(0) else buffer.copyOf(count)
            } ?: ByteArray(0)

            val name = queryDisplayName(uri)
            val header = bytes.joinToString(" ") {
                String.format(Locale.US, "%02X", it.toInt() and 0xFF)
            }
            status.text = "Archivo importado: $name"
            details.text = buildString {
                append("ARCHIVO\\n$name\\n\\n")
                append("CABECERA (primeros ${bytes.size} bytes)\\n")
                append(if (header.isBlank()) "(vacía)" else header)
                append("\\n\\n")
                append("ESTADO DEL PROYECTO\\n")
                append("✓ Selector de archivos Android\\n")
                append("✓ Lectura inicial del archivo\\n")
                append("✓ Diagnóstico hexadecimal básico\\n")
                append("○ Decodificación completa del replay\\n")
                append("○ Motor de reproducción del duelo\\n")
                append("○ Carga de cartas personalizadas y animaciones\\n\\n")
                append("Este prototipo confirma que Android puede abrir el .yrp3d. ")
                append("Aún no reproduce el duelo; esa parte requiere implementar ")
                append("y validar el formato y el motor compatible.")
            }
        } catch (e: Exception) {
            status.text = "No se pudo leer el archivo."
            details.text = e.message ?: "Error desconocido"
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && it.moveToFirst()) return it.getString(index)
        }
        return uri.lastPathSegment ?: "replay.yrp3d"
    }
}
